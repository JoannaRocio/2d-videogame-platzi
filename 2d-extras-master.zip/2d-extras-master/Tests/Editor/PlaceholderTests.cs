using NUnit.Framework;

internal class U2DExtrasPlaceholder 
{
    [Test]
    public void PlaceHolderTest()
    {
        Assert.Pass("2D Extras tests are in a separate package.");
    }
}
